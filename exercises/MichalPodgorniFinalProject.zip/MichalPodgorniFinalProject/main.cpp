#include "FinalProject.h"

int main()
{
	FinalProject viewerApplication;
	return viewerApplication.Run();
}
